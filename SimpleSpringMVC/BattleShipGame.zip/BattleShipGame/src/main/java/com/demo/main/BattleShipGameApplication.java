package com.demo.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BattleShipGameApplication {

	public static void main(String[] args) {
		SpringApplication.run(BattleShipGameApplication.class, args);
	}
}
